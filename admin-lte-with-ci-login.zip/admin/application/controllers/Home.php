<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_loggedin();
	}
	private function is_loggedin()
	{
		if(!$this->session->userdata('fname')){
			redirect('Login/index');
		}
	}
	public function index()
	{
		$data['title'] = 'Dashboard';
		$this->load->model('admin/Message_model');
		$data['messages'] = $this->Message_model->count_messages();
		$this->load->view('admin/incl/header', $data);
		$this->load->view('admin/dashboard');
		$this->load->view('admin/incl/footer');
	}

	public function messages()
	{
		$data['title'] = 'Messages';
		$this->load->model('admin/Message_model');
		$data['messages'] = $this->Message_model->messages();
		$this->load->view('admin/incl/header', $data);
		$this->load->view('admin/messages');
		$this->load->view('admin/incl/footer');
	}
	public function message_detail($id)
	{
		$data['title'] = 'Read Message';
		$this->load->model('admin/Message_model');
		$data['message_detail'] = $this->Message_model->message_detail($id);
		$this->load->view('admin/incl/header', $data);
		$this->load->view('admin/message-detail');
		$this->load->view('admin/incl/footer');
	}
	public function compose_message($id)
	{
		$data['title'] = 'Compose Message';
		$this->load->model('admin/Message_model');
		$data['message'] = $this->Message_model->message_detail($id);
		$this->load->view('admin/incl/header', $data);
		$this->load->view('admin/compose_message');
		$this->load->view('admin/incl/footer');
	}
	public function send_reply()
	{
			$email = $this->security->xss_clean($this->input->post('email'));
			$subject = $this->security->xss_clean($this->input->post('subject'));
			$message_body = $this->security->xss_clean($this->input->post('message_body'));
			$id = $this->security->xss_clean($this->input->post('id'));
			$this->load->model('admin/Message_model');
			$status = $this->Message_model->reply_status_update($id);
			if($status)
			{
				$this->send_reply_email($email, $subject, $message_body);
			}
	}
	public function message_delete($id)
	{
		$this->load->model('admin/Message_model');
		$status = $this->Message_model->message_delete($id);
		if($status)
			$this->session->set_flashdata("email_message","Message has been deleted");
		else
			$this->session->set_flashdata("email_message","You have encountered an error");
		redirect('Home/messages');
	}
	public function send_reply_email($email, $subject, $message_body)
	{
		$this->load->library('email');

		$this->email->set_mailtype('html');
		$this->email->from($this->config->item('bot_email'), 'Admin, Helping Hands');
		$this->email->to($email);
		$this->email->subject($subject);

		$this->email->message($message_body);
		//Send mail
		if($this->email->send())
			$this->session->set_flashdata("email_message","password reset link has been sent to your email, Please check your spam/junk folder also if you don't receive link.");
		else
			$this->session->set_flashdata("email_message","You have encountered an error");
		redirect('Home/messages');
	}

	public function pilotReviews()
	{
		$data['title'] = 'Pilot Reviews';
		$this->load->model('admin/Message_model');
		$data['messages'] = $this->Message_model->count_messages();
		$this->load->view('admin/incl/header', $data);
		$this->load->view('admin/pilot-reviews');
		$this->load->view('admin/incl/footer');
	}
	public function googleReviews()
	{
		$data['title'] = 'Google reviews';
		$this->load->model('admin/Message_model');
		$data['messages'] = $this->Message_model->count_messages();
		$this->load->view('admin/incl/header', $data);
		$this->load->view('admin/google-reviews');
		$this->load->view('admin/incl/footer');
	}

}

