<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Message_model extends CI_Model {
	
	public function messages()
	{
		$query = $this->db->get('tbl_contact');
		return $query ? $query->result():false;
	}
	public function message_detail($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('tbl_contact');
		return $query ? $query->row():false;
	}
	public function reply_status_update($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->update('tbl_contact',array('status'=>1));
		return $query ? true:false;
	}
	public function message_delete($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->delete('tbl_contact');
		return $query ? true:false;
	}
	public function count_messages()
	{
		$this->db->where('status',0);
		$query = $this->db->get('tbl_contact');
		return $query ? $query->num_rows():false;
	}

}
