<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1><?php echo $title;?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">users</li>
					</ol>
				</div>
			</div>
		</div><!-- /.container-fluid -->
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-12">

				<?php if($this->session->flashdata('msg')){?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
						<strong>Info!</strong> <?php echo $this->session->flashdata('msg');?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php }?>
				<?php if($this->session->flashdata('email_message')){?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
						<strong>Info!</strong> <?php echo $this->session->flashdata('email_message');?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php }?>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="users" class="table table-bordered table-striped">
								<thead>
								<tr>
									<th>Sr.</th>
									<th>Name</th>
									<th>Contact</th>
									<th>Message</th>
									<th>status</th>
								</tr>
								</thead>
								<tbody>

								<?php
								$sr = 1;
								foreach ($messages as $message){?>
								<tr>
									<td><?php echo $sr;?></td>
									<td><?php echo $message->fullname;?></td>
									<td><a href="tel:<?php echo $message->phone;?>"><?php echo $message->phone;?></a></td>
									<td><a data-toggle="tooltip" data-placement="top" title="Click to read full message" href="<?php echo base_url('Home/message_detail/'.$message->id);?>"><?php if(strlen($message->message)>50){echo substr($message->message, 0, 50) . '...';}else{echo $message->message;}?></a></td>
									<td>
										<?php if($message->status == TRUE){?>
											<a href="#"><span class="badge badge-success">replied</span></a>
										<?php }else{?>
											<a href="<?php echo base_url('Home/compose_message/'.$message->id);?>"><span class="badge badge-danger">not replied</span></a>
										<?php }?>
									</td>
								</tr>
								<?php
								$sr++;
								}?>


								</tbody>
								<tfoot>
								<tr>
									<th>Sr.</th>
									<th>Name</th>
									<th>Contact</th>
									<th>Message</th>
									<th>status</th>
								</tr>
								</tfoot>
							</table>
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->
			</div>
			<!-- /.col -->
		</div>
		<!-- /.row -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
