<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1><?php echo $title;?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">users</li>
					</ol>
				</div>
			</div>
		</div><!-- /.container-fluid -->
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-12">

				<?php if($this->session->flashdata('msg')){?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
						<strong>Info!</strong> <?php echo $this->session->flashdata('msg');?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php }?>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="users" class="table table-bordered table-striped">
								<thead>
								<tr>
									<th>Sr.</th>
									<th>Preference</th>
									<th>Amount</th>
									<th>Payment mode</th>
									<th>Remarks</th>
									<th>Created On</th>
									<th>Actions</th>
								</tr>
								</thead>
								<tbody>

								<?php
								$n = 1;
								foreach ($donor_history as $history){?>
									<tr>
										<td><?php echo $n;?></td>
										<td><?php echo $history->preference;?></td>
										<td><?php echo 'Rs. '.$history->amount.'/-';?></td>
										<td><?php echo $history->payment_mode;?></td>
										<td><?php echo $history->remarks;?></td>
										<td><?php echo $history->created_at;?></td>

										<td>
											<a onclick="return confirm('Are you sure to delete This record?');" class="btn btn-danger btn-sm" href="<?php echo base_url('Home/delete_history/'.$history->id);?>" data-toggle="tooltip" data-container="body" title="delete">
												<i class="fas fa-trash"></i>
											</a>
										</td>
									</tr>
									<?php $n ++; } ?>


								</tbody>
								<tfoot>
								<tr>
									<th>Sr.</th>
									<th>Preference</th>
									<th>Amount</th>
									<th>Payment mode</th>
									<th>Remarks</th>
									<th>Created On</th>
									<th>Actions</th>
								</tr>
								</tfoot>
							</table>
						</div>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->
			</div>
			<!-- /.col -->
		</div>
		<!-- /.row -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
