<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1><?php echo $title;?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?php echo base_url('Home/')?>">Home</a></li>
						<li class="breadcrumb-item active"><a href="<?php echo base_url('Home/messages')?>">Messages</a></li>
						<li class="breadcrumb-item active">Message Detail</li>
					</ol>
				</div>
			</div>
		</div><!-- /.container-fluid -->
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-primary card-outline">
						<div class="card-header">
							<h3 class="card-title">Read Message <small><span class="badge badge-info">
										<?php if($message_detail->status){echo 'Already replied';}else{echo 'Not yet replied';}?>
									</span></small></h3>

							<div class="card-tools">
								<div class="btn-group">
									<a href="<?php echo base_url('Home/messages')?>" class="btn btn-default btn-sm" data-toggle="tooltip" title="Previous"><i class="fas fa-chevron-left"></i></a>
									<a href="<?php echo base_url('Home/message_delete/'.$message_detail->id);?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-container="body" title="Delete">
										<i class="far fa-trash-alt"></i>
									</a>
									<a href="<?php echo base_url('Home/compose_message/'.$message_detail->id);?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-container="body" title="Reply">
										<i class="fas fa-reply"></i>
									</a>

								</div>
								<!-- /.btn-group -->

							</div>
						</div>
						<!-- /.card-header -->
						<div class="card-body p-0">
							<div class="mailbox-read-info">
								<h5>From:</h5>
								<h5><?php echo $message_detail->fullname;?></h5>
								<h6><?php echo $message_detail->email;?><span class="mailbox-read-time float-right"><?php echo $message_detail->created_at;?></span></h6>

							</div>
							<!-- /.mailbox-read-info -->
							<div class="mailbox-read-message">
								<p>Hello Admin,</p>

								<p><?php echo $message_detail->message;?></p>
								<p>Thanks,<br><?php echo $message_detail->fullname;?></p>
							</div>
							<!-- /.mailbox-read-message -->
						</div>
						<!-- /.card-body -->
						<div class="card-footer">
							<div class="float-right">
								<a href="<?php echo base_url('Home/compose_message/'.$message_detail->id);?>" class="btn btn-default"><i class="fas fa-reply"></i> Reply</a>
							</div>
							<a onclick="return confirm('Are you sure to delete this message permanently?');" href="<?php echo base_url('Home/message_delete/'.$message_detail->id);?>" class="btn btn-default"><i class="far fa-trash-alt"></i> Delete</a>
						</div>
						<!-- /.card-footer -->
					</div>
					<!-- /.card -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
